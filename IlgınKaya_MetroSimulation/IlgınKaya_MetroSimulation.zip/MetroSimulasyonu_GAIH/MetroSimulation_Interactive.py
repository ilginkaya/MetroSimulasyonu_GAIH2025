
from collections import defaultdict, deque
import heapq
from typing import Dict, List, Set, Tuple, Optional
from colorama import Fore, Style, init
import networkx as nx
import matplotlib.pyplot as plt

init(autoreset=True)

class Istasyon:
    def __init__(self, idx: str, ad: str, hat: str):
        self.idx = idx
        self.ad = ad
        self.hat = hat
        self.komsular: List[Tuple['Istasyon', int]] = []

    def komsu_ekle(self, istasyon: 'Istasyon', sure: int):
        self.komsular.append((istasyon, sure))

class MetroAgi:
    def __init__(self):
        self.istasyonlar: Dict[str, Istasyon] = {}
        self.hatlar: Dict[str, List[Istasyon]] = defaultdict(list)

    def istasyon_ekle(self, idx: str, ad: str, hat: str) -> None:
        if idx not in self.istasyonlar:
            istasyon = Istasyon(idx, ad, hat)
            self.istasyonlar[idx] = istasyon
            self.hatlar[hat].append(istasyon)

    def baglanti_ekle(self, istasyon1_id: str, istasyon2_id: str, sure: int) -> None:
        istasyon1 = self.istasyonlar[istasyon1_id]
        istasyon2 = self.istasyonlar[istasyon2_id]
        istasyon1.komsu_ekle(istasyon2, sure)
        istasyon2.komsu_ekle(istasyon1, sure)

    def en_hizli_rota_bul(self, baslangic_id: str, hedef_id: str) -> Optional[Tuple[List[Istasyon], int]]:
        if baslangic_id not in self.istasyonlar or hedef_id not in self.istasyonlar:
            return None

        baslangic = self.istasyonlar[baslangic_id]
        hedef = self.istasyonlar[hedef_id]

        pq = [(0, id(baslangic), baslangic, [baslangic])]
        ziyaret_edildi = {}

        while pq:
            toplam_sure, _, simdiki, yol = heapq.heappop(pq)

            if simdiki == hedef:
                return yol, toplam_sure

            if simdiki in ziyaret_edildi and ziyaret_edildi[simdiki] <= toplam_sure:
                continue

            ziyaret_edildi[simdiki] = toplam_sure

            for komsu, sure in simdiki.komsular:
                yeni_toplam = toplam_sure + sure
                heapq.heappush(pq, (yeni_toplam, id(komsu), komsu, yol + [komsu]))
        return None

def metro_agini_ciz(metro: MetroAgi, rota: Optional[List[Istasyon]] = None):
    G = nx.Graph()

    for istasyon in metro.istasyonlar.values():
        G.add_node(istasyon.idx, label=istasyon.ad)
        for komsu, sure in istasyon.komsular:
            if not G.has_edge(istasyon.idx, komsu.idx):
                G.add_edge(istasyon.idx, komsu.idx, weight=sure)

    pos = nx.spring_layout(G, seed=42)

    node_colors = []
    aktarma_noktalari = {i.idx for i in metro.istasyonlar.values()
                         if sum(1 for hat in metro.hatlar.values() if i in hat) > 1}

    for node in G.nodes():
        if rota and node == rota[0].idx:
            node_colors.append("green")
        elif rota and node == rota[-1].idx:
            node_colors.append("red")
        elif node in aktarma_noktalari:
            node_colors.append("violet")
        else:
            node_colors.append("lightblue")

    nx.draw(G, pos, with_labels=True,
            labels=nx.get_node_attributes(G, 'label'),
            node_color=node_colors, edge_color="gray",
            node_size=1500, font_size=9)

    edge_labels = nx.get_edge_attributes(G, 'weight')
    edge_labels_km = {k: f"{v} km" for k, v in edge_labels.items()}
    nx.draw_networkx_edge_labels(G, pos, edge_labels=edge_labels_km, font_size=8)

    if rota:
        rota_ids = [i.idx for i in rota]
        rota_edges = [(rota_ids[i], rota_ids[i+1]) for i in range(len(rota_ids)-1)]
        nx.draw_networkx_edges(G, pos, edgelist=rota_edges, edge_color="orange", width=3)

    plt.title("Metro Ağı Haritası (Aktarmalar: Mor, Başlangıç: Yeşil, Varış: Kırmızı)")
    plt.show()

if __name__ == "__main__":
    metro = MetroAgi()
    metro.istasyon_ekle("K1", "Kızılay", "Kırmızı Hat")
    metro.istasyon_ekle("K2", "Ulus", "Kırmızı Hat")
    metro.istasyon_ekle("K3", "Demetevler", "Kırmızı Hat")
    metro.istasyon_ekle("K4", "OSB", "Kırmızı Hat")
    metro.istasyon_ekle("M1", "AŞTİ", "Mavi Hat")
    metro.istasyon_ekle("M2", "Kızılay", "Mavi Hat")
    metro.istasyon_ekle("M3", "Sıhhiye", "Mavi Hat")
    metro.istasyon_ekle("M4", "Gar", "Mavi Hat")
    metro.istasyon_ekle("T1", "Batıkent", "Turuncu Hat")
    metro.istasyon_ekle("T2", "Demetevler", "Turuncu Hat")
    metro.istasyon_ekle("T3", "Gar", "Turuncu Hat")
    metro.istasyon_ekle("T4", "Keçiören", "Turuncu Hat")

    metro.baglanti_ekle("K1", "K2", 4)
    metro.baglanti_ekle("K2", "K3", 6)
    metro.baglanti_ekle("K3", "K4", 8)
    metro.baglanti_ekle("M1", "M2", 5)
    metro.baglanti_ekle("M2", "M3", 3)
    metro.baglanti_ekle("M3", "M4", 4)
    metro.baglanti_ekle("T1", "T2", 7)
    metro.baglanti_ekle("T2", "T3", 9)
    metro.baglanti_ekle("T3", "T4", 5)
    metro.baglanti_ekle("K1", "M2", 2)
    metro.baglanti_ekle("K3", "T2", 3)
    metro.baglanti_ekle("M4", "T3", 2)

    print(Fore.YELLOW + "\n=== Metro Simülasyonu Başladı ===\n" + Style.RESET_ALL)
    print("İstasyon ID'leri:", ", ".join(metro.istasyonlar.keys()))
    baslangic = input("Başlangıç istasyon ID'si: ").strip()
    hedef = input("Hedef istasyon ID'si: ").strip()

    rota = metro.en_hizli_rota_bul(baslangic, hedef)
    if rota:
        istasyonlar, sure = rota
        print(Fore.GREEN + f"\nEn hızlı rota ({sure} km):" + Style.RESET_ALL)
        print(" -> ".join(i.ad for i in istasyonlar))
        metro_agini_ciz(metro, rota=istasyonlar)
    else:
        print(Fore.RED + "Rota bulunamadı." + Style.RESET_ALL)
