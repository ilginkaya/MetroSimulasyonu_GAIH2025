
# GAIH Mart 2025 - Metro Simülasyonu Projesi

Bu proje, Global AI Hub Python Bootcamp Mart 2025 dönemi kapsamında geliştirilmiştir. Ankara metrosuna benzer bir metro ağını simüle ederek, iki istasyon arasındaki en hızlı rotayı bulmayı ve bu rotayı görselleştirmeyi amaçlar.

## 🚇 Projenin Amacı

- Metro ağı modelleme (istasyonlar ve bağlantılar)
- En hızlı rotayı bulmak için A* algoritması kullanımı
- Terminal üzerinden kullanıcı girişiyle dinamik rota belirleme
- NetworkX ve Matplotlib ile metro haritası çizimi

## 📁 Dosyalar

- `MetroSimulation_Interactive.py`: Ana uygulama kodu
- `README.md`: Bu açıklama dosyası
- `ornek_gorsel.png`: (isteğe bağlı) Örnek görsel çıktı

## 🛠 Gerekli Kütüphaneler

Kurulum için terminalde aşağıdaki komutu çalıştırabilirsiniz:

```bash
pip install colorama matplotlib networkx
```

## ▶️ Kullanım

1. Terminali açın
2. Dosyanın bulunduğu klasöre gidin:

```bash
cd ~/Downloads  # veya nereye indirdiyseniz
```

3. Programı çalıştırın:

```bash
python3 MetroSimulation_Interactive.py
```

4. Başlangıç ve hedef istasyon ID'lerini girin (örneğin `M1` ve `K4`)
5. En hızlı rota terminalde gösterilecek ve aynı anda grafik açılacaktır.

## 🖼️ Harita Özellikleri

- **Başlangıç noktası**: Yeşil
- **Hedef noktası**: Kırmızı
- **Aktarma noktaları**: Mor
- **Seçilen rota**: Turuncu çizgi
- **Mesafeler**: Kenarlarda `km` olarak gösterilir

## 🎓 Geliştiren

İlginkaya - Python Bootcamp Öğrencisi  
GAIH Mart 2025

---

İyi kodlamalar! 🚀
